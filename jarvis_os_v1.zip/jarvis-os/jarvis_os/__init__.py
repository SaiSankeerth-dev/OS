"""
Jarvis-OS: Local-First Personal AI Operating System
Synthesizing OpenJarvis (Stanford SAIL / dmrr35), OpenMuse (CopilotKit), and OpenDots.
Author: Sai Sankeerth (@SaiSankeerth-dev)
"""
__version__ = "1.0.0"
