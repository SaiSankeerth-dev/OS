import re
import uuid
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

class SafetyGate:
    """
    Combines Open.Jarvis destructive command blocking with OpenDots Human-in-the-Loop (HITL)
    permission approval cards (Allow Once / Always Allow / Deny).
    """
    DESTRUCTIVE_PATTERNS = [
        r"rm\s+-rf\s+/",
        r"mkfs\.",
        r"dd\s+if=",
        r":\(\)\{\s*:\|:&\s*\};:",
        r"curl\s+.*\|\s*(ba)?sh",
        r"wget\s+.*\|\s*(ba)?sh",
        r"powershell.*-enc",
        r"format\s+[a-zA-Z]:",
        r"del\s+/s\s+/q\s+c:\\",
    ]

    RISKY_ACTIONS = {"shell_exec", "file_write", "file_delete", "git_push", "network_tunnel"}

    def __init__(self):
        self.always_allowed_rules: set = set()
        self.pending_approvals: Dict[str, dict] = {}
        self.audit_log: List[dict] = []

    def inspect_command(self, command: str) -> Tuple[bool, str]:
        """Hard security gate against destructive shell patterns."""
        for pattern in self.DESTRUCTIVE_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                self._log("BLOCKED_DESTRUCTIVE", command, f"Matched pattern: {pattern}")
                return False, f"Blocked by Jarvis Safety Gate (matched unsafe pattern: {pattern})"
        return True, "Safe"

    def request_approval(self, dot_name: str, action_type: str, payload: str) -> dict:
        """
        OpenDots-style approval workflow.
        Returns status: 'approved' | 'waiting_approval' | 'blocked'
        """
        if action_type == "shell_exec":
            is_safe, reason = self.inspect_command(payload)
            if not is_safe:
                return {"status": "blocked", "reason": reason, "approval_id": None}

        rule_key = f"{dot_name}:{action_type}"
        if action_type not in self.RISKY_ACTIONS or rule_key in self.always_allowed_rules:
            self._log("AUTO_APPROVED", payload, f"Rule {rule_key}")
            return {"status": "approved", "reason": "Permitted by policy", "approval_id": None}

        approval_id = f"apr_{uuid.uuid4().hex[:8]}"
        card = {
            "approval_id": approval_id,
            "dot_name": dot_name,
            "action_type": action_type,
            "payload": payload,
            "status": "waiting_approval",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "options": ["allow_once", "always_allow", "deny"],
        }
        self.pending_approvals[approval_id] = card
        self._log("WAITING_APPROVAL", payload, f"Approval ID: {approval_id}")
        return card

    def resolve_approval(self, approval_id: str, decision: str) -> dict:
        """Resolve a paused task approval card ('allow_once', 'always_allow', 'deny')."""
        if approval_id not in self.pending_approvals:
            return {"error": f"Approval ID {approval_id} not found"}

        card = self.pending_approvals.pop(approval_id)
        if decision == "always_allow":
            rule_key = f"{card['dot_name']}:{card['action_type']}"
            self.always_allowed_rules.add(rule_key)
            card["status"] = "approved"
        elif decision == "allow_once":
            card["status"] = "approved"
        else:
            card["status"] = "denied"

        card["resolved_at"] = datetime.now(timezone.utc).isoformat()
        card["decision"] = decision
        self._log(f"RESOLVED_{decision.upper()}", card["payload"], f"Approval ID: {approval_id}")
        return card

    def _log(self, event: str, target: str, detail: str):
        self.audit_log.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": event,
            "target": target[:120],
            "detail": detail,
        })
