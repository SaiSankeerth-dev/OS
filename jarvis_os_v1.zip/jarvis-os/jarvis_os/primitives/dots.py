import os
from dataclasses import dataclass, field
from typing import List, Set, Dict, Any

@dataclass
class DotConfig:
    """
    OpenDots Specialist Coworker specification.
    Each Dot has one focused job, explicit tool permissions, and Space access.
    """
    dot_id: str
    name: str
    role: str
    instructions: str
    permissions: Set[str] = field(default_factory=set)  # {"browser", "files", "shell", "memory"}
    authorized_spaces: Set[str] = field(default_factory=lambda: {"engineering-hq"})


class AgentComputerWorker:
    """
    OpenMuse-inspired Agent Computer.
    Provides an isolated workspace directory, virtual browser session history,
    and terminal execution with 'Take Control' user override state.
    """
    def __init__(self, workspace_root: str = "/tmp/jarvis_computer_workspace"):
        self.workspace_root = workspace_root
        os.makedirs(self.workspace_root, exist_ok=True)
        self.user_took_control: bool = False
        self.browser_tabs: List[Dict[str, str]] = [
            {"url": "http://localhost:8000/hud", "title": "Jarvis-OS 3D Cyber HUD", "status": "active"}
        ]
        self.terminal_history: List[Dict[str, Any]] = []

    def toggle_take_control(self, take_control: bool) -> Dict[str, Any]:
        """OpenMuse 'Take Control' feature allowing the human to take over the browser/terminal."""
        self.user_took_control = take_control
        mode = "HUMAN_CONTROL" if take_control else "AGENT_AUTONOMOUS"
        return {"computer_mode": mode, "workspace": self.workspace_root}

    def open_url(self, dot_name: str, url: str) -> Dict[str, Any]:
        tab = {"url": url, "title": f"Visited by {dot_name}: {url}", "status": "loaded"}
        self.browser_tabs.append(tab)
        return tab

    def write_workspace_file(self, rel_path: str, content: str) -> str:
        safe_name = os.path.basename(rel_path)
        full_path = os.path.join(self.workspace_root, safe_name)
        with open(full_path, "w") as f:
            f.write(content)
        self.terminal_history.append({"cmd": f"write {safe_name}", "exit_code": 0, "bytes": len(content)})
        return full_path


DEFAULT_DOTS: Dict[str, DotConfig] = {
    "scout": DotConfig(
        dot_id="scout",
        name="Scout",
        role="Deep Research & Web Specialist",
        instructions="Investigate topics, read documentation, and synthesize findings with citations.",
        permissions={"browser", "memory"},
    ),
    "forge": DotConfig(
        dot_id="forge",
        name="Forge",
        role="Coding & Autonomous Terminal Engineer",
        instructions="Write clean Python/TypeScript code, run unit tests in the Agent Computer, and propose fixes.",
        permissions={"files", "shell", "memory"},
    ),
    "scribe": DotConfig(
        dot_id="scribe",
        name="Scribe",
        role="Space & Documentation Architect",
        instructions="Turn research and conversations into structured, revision-safe Markdown pages in authorized Spaces.",
        permissions={"files", "memory"},
    ),
    "sentinel": DotConfig(
        dot_id="sentinel",
        name="Sentinel",
        role="System Diagnostics & Security Monitor",
        instructions="Monitor hardware telemetry, audit safety gates, and manage cron schedules.",
        permissions={"memory"},
    ),
}
