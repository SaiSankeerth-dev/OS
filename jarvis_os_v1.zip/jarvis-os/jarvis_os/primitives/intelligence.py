import os
import platform
import multiprocessing
from typing import Dict, Any

class HardwareIntelligence:
    """
    OpenJarvis Primitive 1: Intelligence.
    Detects CPU cores, RAM, OS, and GPU availability to recommend optimal local/hybrid models.
    """
    MODEL_CATALOG = [
        {"id": "qwen3.5:35b", "provider": "ollama", "min_ram_gb": 24, "tier": "workstation", "task": "orchestrator"},
        {"id": "qwen2.5-coder:14b", "provider": "ollama", "min_ram_gb": 12, "tier": "desktop", "task": "coding"},
        {"id": "llama3.2:8b", "provider": "ollama", "min_ram_gb": 8, "tier": "laptop", "task": "general"},
        {"id": "qwen2.5:3b", "provider": "ollama", "min_ram_gb": 4, "tier": "edge", "task": "fast_local"},
        {"id": "gemini-2.5-flash", "provider": "cloud_gemini", "min_ram_gb": 0, "tier": "cloud_fallback", "task": "multimodal"},
        {"id": "llama-3.3-70b-versatile", "provider": "cloud_groq", "min_ram_gb": 0, "tier": "cloud_fallback", "task": "fast_cloud"},
    ]

    @classmethod
    def detect_hardware(cls) -> Dict[str, Any]:
        cpu_count = multiprocessing.cpu_count()
        ram_gb = 8.0
        try:
            if hasattr(os, "sysconf") and "SC_PAGE_SIZE" in os.sysconf_names and "SC_PHYS_PAGES" in os.sysconf_names:
                ram_bytes = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
                ram_gb = round(ram_bytes / (1024 ** 3), 2)
        except Exception:
            pass

        gpu_vendor = "CPU-Only (Unified/Integrated)"
        if platform.system() == "Darwin" and platform.machine() == "arm64":
            gpu_vendor = "Apple Silicon Unified GPU (MLX / Metal)"
        elif os.path.exists("/proc/driver/nvidia"):
            gpu_vendor = "NVIDIA CUDA GPU"

        recommended = "qwen2.5:3b"
        for model in cls.MODEL_CATALOG:
            if model["provider"] == "ollama" and ram_gb >= model["min_ram_gb"]:
                recommended = model["id"]
                break

        return {
            "os": f"{platform.system()} {platform.release()}",
            "arch": platform.machine(),
            "cpu_cores": cpu_count,
            "ram_gb": ram_gb,
            "gpu": gpu_vendor,
            "recommended_local_model": recommended,
            "preferred_engine": "ollama",
        }
