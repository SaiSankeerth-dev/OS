import sqlite3
import json
import hashlib
from datetime import datetime, timezone
from typing import List, Dict, Optional, Any

class MemoryAndSpaces:
    """
    Combines OpenJarvis Persistent Local Memory + OpenDots 'Spaces & Pages' with
    optimistic concurrency revision checks so agent edits never collide with user edits.
    """
    def __init__(self, db_path: str = ":memory:"):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self):
        cur = self.conn.cursor()
        cur.executescript("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                tags TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS spaces (
                space_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS pages (
                page_id TEXT PRIMARY KEY,
                space_id TEXT NOT NULL,
                title TEXT NOT NULL,
                markdown TEXT NOT NULL,
                revision INTEGER NOT NULL DEFAULT 1,
                updated_by TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(space_id) REFERENCES spaces(space_id)
            );
        """)
        self.conn.commit()
        # Seed default OpenDots Space
        self.create_space("engineering-hq", "Engineering & AI Lab", "Primary workspace for Jarvis-OS and BEEE/Coding notes")

    def remember(self, content: str, category: str = "general", tags: str = "") -> int:
        cur = self.conn.cursor()
        now = datetime.now(timezone.utc).isoformat()
        cur.execute(
            "INSERT INTO memories (category, content, tags, created_at) VALUES (?, ?, ?, ?)",
            (category, content, tags, now)
        )
        self.conn.commit()
        return cur.lastrowid

    def search_memory(self, query: str) -> List[Dict[str, Any]]:
        cur = self.conn.cursor()
        q = f"%{query}%"
        cur.execute(
            "SELECT * FROM memories WHERE content LIKE ? OR tags LIKE ? OR category LIKE ? ORDER BY id DESC LIMIT 10",
            (q, q, q)
        )
        return [dict(row) for row in cur.fetchall()]

    def export_masked_memory(self) -> List[Dict[str, Any]]:
        """Open.Jarvis privacy-aware masked JSON export."""
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM memories ORDER BY id DESC")
        rows = [dict(r) for r in cur.fetchall()]
        for r in rows:
            if "secret" in r["content"].lower() or "key" in r["content"].lower():
                r["content"] = "[REDACTED_BY_JARVIS_PRIVACY_SHIELD]"
        return rows

    def create_space(self, space_id: str, name: str, description: str):
        cur = self.conn.cursor()
        now = datetime.now(timezone.utc).isoformat()
        cur.execute(
            "INSERT OR IGNORE INTO spaces (space_id, name, description, created_at) VALUES (?, ?, ?, ?)",
            (space_id, name, description, now)
        )
        self.conn.commit()

    def save_page(self, space_id: str, page_id: str, title: str, markdown: str, author: str, expected_revision: Optional[int] = None) -> Dict[str, Any]:
        """
        OpenDots revision-safe page editor.
        Stops stale edits from overwriting newer content.
        """
        cur = self.conn.cursor()
        cur.execute("SELECT revision FROM pages WHERE page_id = ?", (page_id,))
        existing = cur.fetchone()
        now = datetime.now(timezone.utc).isoformat()

        if existing is None:
            cur.execute(
                "INSERT INTO pages (page_id, space_id, title, markdown, revision, updated_by, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?)",
                (page_id, space_id, title, markdown, author, now)
            )
            self.conn.commit()
            return {"status": "created", "page_id": page_id, "revision": 1}

        current_rev = existing["revision"]
        if expected_revision is not None and expected_revision != current_rev:
            return {
                "status": "conflict",
                "error": f"Revision mismatch: expected v{expected_revision}, but page is at v{current_rev}. Draft preserved.",
                "current_revision": current_rev
            }

        new_rev = current_rev + 1
        cur.execute(
            "UPDATE pages SET title = ?, markdown = ?, revision = ?, updated_by = ?, updated_at = ? WHERE page_id = ?",
            (title, markdown, new_rev, author, now, page_id)
        )
        self.conn.commit()
        return {"status": "updated", "page_id": page_id, "revision": new_rev}

    def get_pages(self, space_id: Optional[str] = None) -> List[Dict[str, Any]]:
        cur = self.conn.cursor()
        if space_id:
            cur.execute("SELECT * FROM pages WHERE space_id = ? ORDER BY updated_at DESC", (space_id,))
        else:
            cur.execute("SELECT * FROM pages ORDER BY updated_at DESC")
        return [dict(r) for r in cur.fetchall()]
