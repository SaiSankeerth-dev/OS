from datetime import datetime, timezone
from typing import List, Dict, Any

class TraceLearningLoop:
    """
    OpenJarvis Primitive 5: Learning.
    Logs interaction traces (prompt, dot, latency, energy, approval outcome)
    and synthesizes routing/prompt optimizations via `jarvis optimize`.
    """
    def __init__(self):
        self.traces: List[Dict[str, Any]] = []
        self.learned_skills: List[str] = [
            "local-first-routing: Route arithmetic & system diagnostics to deterministic local rules (0J overhead).",
            "hitl-safety: Pause shell_exec and file_write on first invocation until user grants Always Allow.",
        ]

    def record_trace(self, query: str, dot_id: str, latency_ms: float, energy_joules: float, success: bool):
        self.traces.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "query": query,
            "dot_id": dot_id,
            "latency_ms": latency_ms,
            "energy_joules": energy_joules,
            "success": success,
        })

    def optimize(self) -> Dict[str, Any]:
        total = len(self.traces)
        if total == 0:
            return {"status": "no_traces_yet", "total_traces": 0, "learned_skills": self.learned_skills}

        avg_latency = round(sum(t["latency_ms"] for t in self.traces) / total, 2)
        total_energy = round(sum(t["energy_joules"] for t in self.traces), 4)
        new_skill = f"trace-opt-{total}: Tuned {self.traces[-1]['dot_id']} routing (avg {avg_latency}ms, {total_energy}J cumulative)."
        if new_skill not in self.learned_skills:
            self.learned_skills.append(new_skill)

        return {
            "status": "optimized",
            "total_traces": total,
            "avg_latency_ms": avg_latency,
            "total_energy_joules": total_energy,
            "learned_skills": self.learned_skills,
        }
