from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from .primitives.intelligence import HardwareIntelligence
from .primitives.engine import InferenceEngine
from .primitives.memory import MemoryAndSpaces
from .primitives.safety import SafetyGate
from .primitives.dots import DEFAULT_DOTS, AgentComputerWorker
from .primitives.learning import TraceLearningLoop

class JarvisOSRuntime:
    """
    Master Jarvis-OS Kernel combining:
    - Open.Jarvis Runtime State Machine (BOOTING -> STANDBY -> LISTENING -> PROCESSING -> WAITING_APPROVAL -> EXECUTING -> SPEAKING)
    - AG-UI Protocol Event Stream (for live HUD rendering)
    - OpenDots Specialist Coworker Routing & Space/Page management
    - OpenMuse Agent Computer & Take-Control Workspace
    - OpenJarvis 5 Primitives & Cron Scheduler
    """
    VALID_STATES = (
        "BOOTING", "STANDBY", "LISTENING", "PROCESSING",
        "WAITING_APPROVAL", "EXECUTING", "SPEAKING", "ERROR", "OFFLINE"
    )

    def __init__(self, db_path: str = ":memory:"):
        self.state = "BOOTING"
        self.hardware = HardwareIntelligence.detect_hardware()
        self.engine = InferenceEngine(default_model=self.hardware["recommended_local_model"])
        self.memory = MemoryAndSpaces(db_path=db_path)
        self.safety = SafetyGate()
        self.dots = DEFAULT_DOTS.copy()
        self.computer = AgentComputerWorker()
        self.learning = TraceLearningLoop()
        self.schedules: List[Dict[str, Any]] = [
            {"id": 1, "cron": "0 8 * * *", "task": "morning-digest", "dot": "sentinel", "status": "active"}
        ]
        self.ag_ui_events: List[Dict[str, Any]] = []
        self._transition("STANDBY", "Kernel initialized")

    def _transition(self, new_state: str, detail: str = ""):
        assert new_state in self.VALID_STATES, f"Invalid state: {new_state}"
        self.state = new_state
        self._emit_ag_ui("STATE_SNAPSHOT", {"state": new_state, "detail": detail})

    def _emit_ag_ui(self, event_type: str, payload: Dict[str, Any]):
        """AG-UI Protocol compatible event emitter (used by OpenMuse & OpenDots)."""
        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "type": event_type,
            "payload": payload,
        }
        self.ag_ui_events.append(event)

    def select_dot(self, query: str, preferred_dot: Optional[str] = None) -> str:
        if preferred_dot and preferred_dot in self.dots:
            return preferred_dot
        ql = query.lower()
        if any(w in ql for w in ["code", "python", "script", "shell", "terminal", "bug", "fix"]):
            return "forge"
        if any(w in ql for w in ["page", "doc", "note", "write", "draft", "space"]):
            return "scribe"
        if any(w in ql for w in ["status", "health", "cpu", "ram", "schedule", "diagnostic", "morning"]):
            return "sentinel"
        return "scout"

    def handle_command(
        self,
        query: str,
        preferred_dot: Optional[str] = None,
        action_type: Optional[str] = None,
        action_payload: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Full end-to-end command lifecycle with safety gates, permission checks, and trace learning."""
        self._transition("LISTENING", f"Received input: {query[:60]}")
        dot_id = self.select_dot(query, preferred_dot)
        dot = self.dots[dot_id]
        self._transition("PROCESSING", f"Assigned to Dot '{dot.name}' ({dot.role})")

        # Check per-Dot permission & Safety Gate if a tool action is requested
        if action_type:
            required_perm = {
                "shell_exec": "shell",
                "file_write": "files",
                "browser_open": "browser",
            }.get(action_type, "memory")

            if required_perm not in dot.permissions:
                self._transition("ERROR", f"Dot '{dot.name}' lacks '{required_perm}' permission")
                return {
                    "status": "permission_denied",
                    "dot": dot.name,
                    "error": f"Dot '{dot.name}' only holds permissions {sorted(dot.permissions)} (missing '{required_perm}').",
                    "state": self.state,
                }

            approval = self.safety.request_approval(dot.dot_id, action_type, action_payload or query)
            if approval["status"] == "blocked":
                self._transition("ERROR", approval["reason"])
                return {"status": "blocked", "dot": dot.name, "reason": approval["reason"], "state": self.state}

            if approval["status"] == "waiting_approval":
                self._transition("WAITING_APPROVAL", f"Paused for approval {approval['approval_id']}")
                self._emit_ag_ui("TOOL_APPROVAL_REQUEST", approval)
                return {
                    "status": "waiting_approval",
                    "dot": dot.name,
                    "approval_card": approval,
                    "state": self.state,
                }

        # Execute tool / inference
        self._transition("EXECUTING", f"Running on Engine ({self.engine.default_model})")
        mem_hits = self.memory.search_memory(query)
        context_str = "; ".join(m["content"] for m in mem_hits)

        tool_output = None
        if action_type == "file_write" and action_payload:
            path = self.computer.write_workspace_file("jarvis_artifact.txt", action_payload)
            tool_output = {"file_written": path}
        elif action_type == "browser_open" and action_payload:
            tool_output = self.computer.open_url(dot.name, action_payload)

        gen = self.engine.generate(query, dot_role=dot.name, context=context_str)
        self.learning.record_trace(query, dot.dot_id, gen["latency_ms"], gen["energy_joules"], True)

        self._transition("SPEAKING", "Delivering response")
        self._emit_ag_ui("TEXT_MESSAGE_CONTENT", {"dot": dot.name, "text": gen["content"]})
        self._transition("STANDBY", "Ready")

        return {
            "status": "completed",
            "dot": dot.name,
            "role": dot.role,
            "response": gen["content"],
            "telemetry": {
                "model": gen["model"],
                "latency_ms": gen["latency_ms"],
                "energy_joules": gen["energy_joules"],
                "tokens": gen["tokens"],
            },
            "tool_output": tool_output,
            "state": self.state,
        }
