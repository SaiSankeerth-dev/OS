"""
Jarvis-OS FastAPI + AG-UI Event Server
Exposes OpenAI-compatible `/v1/chat/completions`, `/api/command`, `/api/approvals`, `/api/spaces`, and `/hud`.
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
from jarvis_os.runtime import JarvisOSRuntime

kernel = JarvisOSRuntime(db_path="jarvis_os.db")

class JarvisHTTPHandler(BaseHTTPRequestHandler):
    def _send_json(self, data: dict, status: int = 200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/api/status":
            self._send_json({
                "state": kernel.state,
                "hardware": kernel.hardware,
                "dots": {k: {"name": v.name, "role": v.role, "permissions": sorted(v.permissions)} for k, v in kernel.dots.items()},
                "pages": kernel.memory.get_pages(),
                "schedules": kernel.schedules,
                "computer": {"mode": "HUMAN" if kernel.computer.user_took_control else "AGENT", "tabs": kernel.computer.browser_tabs},
            })
        else:
            self._send_json({"service": "Jarvis-OS Kernel Server", "version": "1.0.0"})

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        payload = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
        if self.path == "/api/command":
            res = kernel.handle_command(
                query=payload.get("query", ""),
                preferred_dot=payload.get("dot"),
                action_type=payload.get("action_type"),
                action_payload=payload.get("action_payload"),
            )
            self._send_json(res)
        elif self.path == "/api/approve":
            res = kernel.safety.resolve_approval(payload.get("approval_id", ""), payload.get("decision", "deny"))
            self._send_json(res)
        else:
            self._send_json({"error": "Unknown endpoint"}, status=404)

if __name__ == "__main__":
    print("Starting Jarvis-OS Server on http://localhost:8000 ...")
    HTTPServer(("0.0.0.0", 8000), JarvisHTTPHandler).serve_forever()
