#!/usr/bin/env bash
set -e
echo "=== Booting Jarvis-OS v1.0 ==="
python3 -m unittest discover -s tests -v
python3 cli.py init
python3 cli.py doctor
echo "Open ui/index.html in your browser or run: python3 server.py"
