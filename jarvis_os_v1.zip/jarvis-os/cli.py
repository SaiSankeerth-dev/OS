#!/usr/bin/env python3
"""
Jarvis-OS Unified CLI (`jarvis init`, `jarvis doctor`, `jarvis ask`, `jarvis dots`, `jarvis optimize`)
"""
import argparse
import json
from jarvis_os.runtime import JarvisOSRuntime

def main():
    parser = argparse.ArgumentParser(description="Jarvis-OS Personal AI Operating System CLI")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("init", help="Auto-detect hardware and initialize Jarvis-OS")
    sub.add_parser("doctor", help="Run full diagnostics across all 5 OpenJarvis primitives")
    sub.add_parser("dots", help="List configured OpenDots specialist coworkers and permissions")
    sub.add_parser("optimize", help="Run OpenJarvis trace learning optimizer")

    ask_p = sub.add_parser("ask", help="Send a command to Jarvis-OS")
    ask_p.add_argument("prompt", type=str, help="Command or question")
    ask_p.add_argument("--dot", type=str, default=None, help="Target Dot (scout, forge, scribe, sentinel)")

    args = parser.parse_args()
    kernel = JarvisOSRuntime()

    if args.cmd == "init":
        print(json.dumps({"status": "initialized", "hardware": kernel.hardware}, indent=2))
    elif args.cmd == "doctor":
        res = kernel.handle_command("Run system diagnostic and health check", preferred_dot="sentinel")
        print(json.dumps({"status": "healthy", "diagnostics": res, "hardware": kernel.hardware}, indent=2))
    elif args.cmd == "dots":
        dots_info = {k: {"role": v.role, "permissions": sorted(v.permissions)} for k, v in kernel.dots.items()}
        print(json.dumps(dots_info, indent=2))
    elif args.cmd == "optimize":
        print(json.dumps(kernel.learning.optimize(), indent=2))
    elif args.cmd == "ask":
        print(json.dumps(kernel.handle_command(args.prompt, preferred_dot=args.dot), indent=2))
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
