# Jarvis-OS (`SaiSankeerth-dev/OS`)

A local-first, hardware-aware Personal AI Operating System with a 3D Cyber-HUD interface, synthesizing the best architectural patterns from:

1. **OpenJarvis (`open-jarvis/OpenJarvis` & `dmrr35/Open.Jarvis`)**:
   - **5 Composable Primitives**: `Intelligence` (hardware-aware model catalog), `Engine` (local-first Ollama + deterministic fast-path + optional Gemini/Groq fallback with energy/wattage telemetry), `Agents` (orchestrator + specialist routing), `Tools & Memory` (SQLite + masked privacy export), and `Learning` (`jarvis optimize` trace-driven self-improvement).
   - **Runtime State Machine & Safety Gates**: `BOOTING -> STANDBY -> LISTENING -> PROCESSING -> WAITING_APPROVAL -> EXECUTING -> SPEAKING`, plus regex-hardened destructive command blocking.
2. **OpenMuse (`CopilotKit/openmuse`)**:
   - **Agent Computer & Visible Work**: Isolated workspace & browser/terminal worker with AG-UI live event streaming and one-click **Take Control** human override.
3. **OpenDots (`CopilotKit/OpenDots` & `Anil-matcha/open-dots`)**:
   - **Role-Based Specialist Coworkers ("Dots")**: `@forge` (Code/Terminal), `@scout` (Research/Web), `@scribe` (Spaces/Docs), and `@sentinel` (Diagnostics/Cron) with strict per-Dot permission boundaries.
   - **Human-in-the-Loop Approval Cards**: Pauses risky actions (`waiting_approval`) for *Allow Once / Always Allow / Deny*.
   - **Spaces & Revision-Checked Pages**: Optimistic concurrency revision locking so agent edits never overwrite human drafts.

## Quick Start

```bash
# 1. Run the full test suite
python3 -m unittest discover -s tests -v

# 2. Initialize & run diagnostics via CLI
python3 cli.py init
python3 cli.py doctor
python3 cli.py ask "calculate 137 * 42" --dot forge
python3 cli.py optimize

# 3. Launch the Kernel Server & open ui/index.html
python3 server.py
```
