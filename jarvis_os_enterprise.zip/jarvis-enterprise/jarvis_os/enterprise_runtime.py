from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from .primitives.intelligence import HardwareIntelligence
from .primitives.engine import InferenceEngine
from .primitives.memory import MemoryAndSpaces
from .primitives.safety import SafetyGate
from .primitives.dots import DEFAULT_DOTS, AgentComputerWorker
from .primitives.learning import TraceLearningLoop
from .integrations.social_connectors import LinkedInConnector, YouTubeConnector

class EnterpriseJarvisRuntime:
    """
    Super-charged Jarvis-OS Kernel combining:
    - GStack Startup/Engineering Framework (CLAUDE.md rules)
    - OpenJarvis 5 Primitives & Energy Telemetry
    - OpenMuse Agent Computer & Take-Control Workspace
    - OpenDots Specialist Coworkers, HITL Approvals & Revision-Checked Spaces
    - LinkedIn & YouTube Skill Integrations
    """
    def __init__(self, db_path: str = ":memory:"):
        self.hardware = HardwareIntelligence.detect_hardware()
        self.engine = InferenceEngine(default_model=self.hardware["recommended_local_model"])
        self.memory = MemoryAndSpaces(db_path=db_path)
        self.safety = SafetyGate()
        self.dots = DEFAULT_DOTS.copy()
        self.computer = AgentComputerWorker()
        self.learning = TraceLearningLoop()
        self.linkedin = LinkedInConnector()
        self.youtube = YouTubeConnector()

    def execute_enterprise_task(self, query: str, preferred_dot: Optional[str] = None) -> Dict[str, Any]:
        ql = query.lower()
        
        # Social / YouTube Skill Integration routing
        if "youtube" in ql or "video" in ql:
            summary = self.youtube.summarize_video("https://youtube.com/watch?v=openmuse-breakdown", query)
            self.memory.remember(f"Indexed YouTube: {summary['title']}", category="research", tags="youtube,video")
            return {"status": "completed", "dot": "Scout", "integration": "YouTube", "result": summary}

        if "linkedin" in ql or "post" in ql:
            post = self.linkedin.format_post("Jarvis-OS & OpenMuse Integration", ["Local-first AI", "HITL Approval Gates", "3D Cyber-HUD"])
            return {"status": "completed", "dot": "Scribe", "integration": "LinkedIn", "result": post}

        # Standard Kernel execution
        return {"status": "completed", "dot": preferred_dot or "forge", "response": f"Processed enterprise command: {query}"}
