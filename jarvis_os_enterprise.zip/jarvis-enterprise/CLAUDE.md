# Jarvis-OS Enterprise CLAUDE.md (Powered by GStack & OpenJarvis)

## Core Engineering & Startup Principles (GStack Framework)
1. **Local-First & Zero-Leak**: All reasoning and calculations run locally (`ollama/llama3.2:8b` or `qwen2.5:3b`) unless cloud fallback is explicitly invoked.
2. **Rigorous Test Coverage**: Every feature, skill connector, and permission gate must include unit tests (`python3 -m unittest discover`).
3. **Human-in-the-Loop (HITL) Safety**: Destructive shell patterns (`rm -rf /`, `mkfs`) are hard-blocked. Privileged operations pause for approval.
4. **Zero Edit Collisions**: All shared Spaces and Markdown notes use optimistic concurrency revision checking.
